global using ErrorOr;
global using Microsoft.AspNetCore.Mvc;
global using MediatR;