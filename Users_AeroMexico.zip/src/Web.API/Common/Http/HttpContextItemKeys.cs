namespace Web.API.Common.Errors;

public static class HttpContextItemKeys
{
    public const string Erros = "errors";
}