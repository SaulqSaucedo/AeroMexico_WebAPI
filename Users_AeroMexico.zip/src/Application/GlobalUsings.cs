global using ErrorOr;
global using FluentValidation;
global using MediatR;