global using MediatR;
global using Microsoft.EntityFrameworkCore;