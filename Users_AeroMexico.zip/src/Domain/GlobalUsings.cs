global using System.Text.RegularExpressions;
global using Domain.ValueObjects;
global using MediatR;