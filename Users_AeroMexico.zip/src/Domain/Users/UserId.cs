namespace Domain.Users;

public record UserId(Guid Value);