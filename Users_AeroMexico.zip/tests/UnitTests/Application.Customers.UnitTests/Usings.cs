global using Xunit;
global using Moq;
global using FluentAssertions;
global using ErrorOr;